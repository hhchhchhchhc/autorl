# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
from .base import POLICIES
from .marl_policy import MARLPPOPolicy
